"""Generate synthetic sample queue data for demonstration."""
import csv
import random

random.seed(42)

VERTICALS = ["gaming", "childrens", "music", "news", "cooking"]
FLAG_TYPES = ["violence", "spam", "copyright", "misleading", "safe"]
ACCOUNT_TYPES = ["verified", "established", "new", "anonymous"]
DECISIONS = ["remove", "allow", "escalate"]

# Vertical -> likely flag type distribution
VERTICAL_FLAG_DIST = {
    "gaming":    ["violence", "violence", "spam", "misleading"],
    "childrens": ["spam", "spam", "misleading", "safe"],
    "music":     ["copyright", "copyright", "spam", "violence"],
    "news":      ["misleading", "misleading", "spam", "safe"],
    "cooking":   ["safe", "spam", "misleading", "safe"],
}

# Flag type -> likely reviewer decision
FLAG_DECISION_DIST = {
    "violence":   ["remove", "remove", "escalate"],
    "spam":       ["remove", "allow", "remove"],
    "copyright":  ["remove", "escalate", "remove"],
    "misleading": ["escalate", "escalate", "allow"],
    "safe":       ["allow", "allow", "allow"],
}

rows = []
for i in range(200):
    vertical = random.choice(VERTICALS)
    flag_type = random.choice(VERTICAL_FLAG_DIST[vertical])
    decision = random.choice(FLAG_DECISION_DIST[flag_type])
    account_type = random.choice(ACCOUNT_TYPES)

    # Add some realistic correlation between account type and violation rate
    base_vr = {"verified": 0.05, "established": 0.15, "new": 0.35, "anonymous": 0.55}
    channel_vr = round(min(1.0, base_vr[account_type] + random.uniform(-0.05, 0.2)), 3)

    rows.append({
        "item_id": f"item_{i:04d}",
        "vertical": vertical,
        "flag_type": flag_type,
        "flag_confidence": round(random.uniform(0.5, 0.99), 3),
        "audio_signal": round(random.uniform(0.0, 1.0), 3),
        "visual_signal": round(random.uniform(0.0, 1.0), 3),
        "text_signal": round(random.uniform(0.0, 1.0), 3),
        "channel_violation_rate": channel_vr,
        "account_type": account_type,
        "reviewer_decision": decision,
    })

fieldnames = [
    "item_id", "vertical", "flag_type", "flag_confidence",
    "audio_signal", "visual_signal", "text_signal",
    "channel_violation_rate", "account_type", "reviewer_decision"
]

with open("/home/claude/ts-clustering/data/sample/sample_queue.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Generated 200-item synthetic sample queue.")
